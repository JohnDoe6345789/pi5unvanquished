#include "common/Common.h"
#include "BoosterComponent.h"

BoosterComponent::BoosterComponent(Entity& entity, AlienBuildableComponent& r_AlienBuildableComponent)
	: BoosterComponentBase(entity, r_AlienBuildableComponent)
{}

#include "common/Common.h"
#include "LeechComponent.h"

LeechComponent::LeechComponent(Entity& entity, AlienBuildableComponent& r_AlienBuildableComponent, MiningComponent& r_MiningComponent)
	: LeechComponentBase(entity, r_AlienBuildableComponent, r_MiningComponent)
{}

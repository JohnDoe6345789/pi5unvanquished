#include "common/Common.h"
#include "ArmouryComponent.h"

ArmouryComponent::ArmouryComponent(Entity& entity, HumanBuildableComponent& r_HumanBuildableComponent)
	: ArmouryComponentBase(entity, r_HumanBuildableComponent)
{}

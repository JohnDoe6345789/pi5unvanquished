#include "common/Common.h"
#include "TeamComponent.h"

TeamComponent::TeamComponent(Entity& entity, team_t team)
	: TeamComponentBase(entity, team)
{}

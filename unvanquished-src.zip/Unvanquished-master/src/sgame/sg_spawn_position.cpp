/*
===========================================================================

Unvanquished GPL Source Code
Copyright (C) 2012 Unvanquished Developers

This file is part of the Unvanquished GPL Source Code (Unvanquished Source Code).

Unvanquished Source Code is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Unvanquished Source Code is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Unvanquished Source Code.  If not, see <http://www.gnu.org/licenses/>.

In addition, the Unvanquished Source Code is also subject to certain additional terms.
You should have received a copy of these additional terms immediately following the
terms and conditions of the GNU General Public License which accompanied the Unvanquished
Source Code.  If not, please request a copy in writing from id Software at the address
below.

If you have questions concerning this license or the applicable additional terms, you
may contact in writing id Software LLC, c/o ZeniMax Media Inc., Suite 120, Rockville,
Maryland 20850 USA.

===========================================================================
*/

#include "common/Common.h"
#include "sg_local.h"
#include "sg_spawn.h"

void SP_pos_player_spawn( gentity_t * )
{
}

/*
=================================================================================

pos_target

=================================================================================
*/
void SP_pos_target( gentity_t *self )
{
	G_SetOrigin( self, VEC2GLM( self->s.origin ) );
}

/*
=================================================================================

pos_location

=================================================================================
*/

void SP_pos_location( gentity_t *self )
{
	char       *message;
	self->s.eType = entityType_t::ET_LOCATION;
	self->r.svFlags = SVF_BROADCAST;
	trap_LinkEntity( self );  // make the server send them to the clients

	if ( G_SpawnInt( "count", "", &self->mapEntity.customNumber) )
	{
		if ( self->mapEntity.customNumber < 0 )
		{
			self->mapEntity.customNumber = 0;
		}

		if ( self->mapEntity.customNumber > 7 )
		{
			self->mapEntity.customNumber = 7;
		}

		message = va( "%c%c%s^*", Color::Constants::ESCAPE, self->mapEntity.customNumber + '0',
		              self->mapEntity.message );
	}
	else
	{
		message = self->mapEntity.message;
	}

	self->nextPathSegment = level.locationHead;

	self->s.generic1 = message ? G_LocationIndex( message ) : 0;

	level.locationHead = self;

	G_SetOrigin( self, VEC2GLM( self->s.origin ) );
}

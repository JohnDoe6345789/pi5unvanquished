**Image Licensing Notice**

The following images are attributed to [nagoshiashumari](https://www.svgrepo.com/author/nagoshiashumari/) and are licensed under the [GPL License](https://www.svgrepo.com/page/licensing/#GPL):

- `ban.svg`
- `ban.webp`

These images were downloaded from [SVGrepo](https://www.svgrepo.com/svg/499203/hammer-drop).

For more information about the GPL license as it applies to these images, please refer to:
https://www.svgrepo.com/page/licensing/#GPL

Unvanquished base package
=========================

![Unvanquished](ui/assets/logos/fuzzy_blue.png)


About
-----

This is the base package for the [Unvanquished](https://unvanquished.net) game project. This sole package should be enough to make the engine load and make the user reach the main in-game menu, even if some other things are missing. You need to download and build the other packages (or use prebuilt ones) to get a complete in-game experience.

Visit the [Unvanquished website](https://unvanquished.net/) for more information about the game itself.


Credits
-------

- The [Unvanquished team](https://unvanquished.net/about/)
